use Classmate                                    -- create database called Classmate
go
create table Friends                             -- create table called Friends
(
PersonID int Primary key,                        --declare variables and datatype
FirstName varchar(255),
LastName varchar(255),
[Address] varchar(255),
City varchar(255)
);                                               -- insert values in Friends table
Insert into Friends (PersonId,FirstName,Lastname,[Address],City,Marks) values(1,'Rohit','Tanwar','Police Line','Palwal',25)
Insert into Friends (PersonId,FirstName,Lastname,[Address],City,Marks) values(2,'Ajay','Sharma','sector three','Ballabgarh',30)
Insert into Friends (PersonId,FirstName,Lastname,[Address],City,Marks) values(3,'Sanjay','Verma','sector Nine','Faridabad',35)
Insert into Friends (PersonId,FirstName,Lastname,[Address],City,Marks) values(4,'Sumit','Rajput','sector seven','Bihar',40)

create table CLfriends                           -- create another  table called CL(Close Friends )table
 (
 RankingId int Not Null Unique,                  -- Again define variables and datatype 
 FullName varchar(255) Not Null,
 Hobbies varchar(255),
 Industry varchar(255),
);                                               -- insert value in Clfriends table
Insert into CLfriends (RankingId,FullName,Hobbies,Industry,City) values(1,'Rakesh Sharma','Cricket','IT','Haryana')
Insert into CLfriends (RankingId,FullName,Hobbies,Industry,City) values(2,'Ajay Singh','Volleyball','Electronics','Punjab')
Insert into CLfriends (RankingId,FullName,Hobbies,Industry,City) values(3,'Sunil Goel','Chess','Automobile','Gurugram')
Insert into CLfriends (RankingId,FullName,Hobbies,Industry,City) values(4,'Pritam nagar','Basketball','Banking','Bihar')
ALTER TABLE CLfriends                              -- now rename the CLfriends table
ADD Email varchar(255);                            -- Add email column in CLfriends table
ALTER TABLE Friends                                -- now rename the Friends table and add Marks column
ADD Marks int;
ALTER TABLE CLfriends                              -- Again rename the CLfriends table and add City column
ADD City varchar(255);
DELETE FROM Friends WHERE PersonId=1;              -- delete a data from Friends table 
UPDATE Friends                                     -- Now update the Friends table
SET FirstName = 'Rohit', City = 'Gurugram'
WHERE PersonId=2;                                                  
SELECT Friends.PersonID, CLfriends.FullName, Friends.FirstName   -- Now use all joins 
FROM Friends
INNER JOIN CLfriends ON Friends.City=CLfriends.City;
SELECT Friends.PersonID, CLfriends.FullName, Friends.FirstName
FROM Friends
LEFT JOIN CLfriends ON Friends.City=CLfriends.City;
SELECT Friends.PersonID, CLfriends.FullName, Friends.FirstName
FROM Friends
RIGHT JOIN CLfriends ON Friends.City=CLfriends.City;
SELECT Friends.PersonID, CLfriends.FullName, Friends.FirstName
FROM Friends
FULL JOIN CLfriends ON Friends.City=CLfriends.City;
select*from Friends
select*from CLfriends
ORDER BY RankingId ASC;                                                  -- use order by command
DELETE FROM CLfriends WHERE RankingId=1 FullName='Ajay Singh';




